package kz.c.signscan;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class StageAttack {

    public static void pwn(Context ctx) {
        Log.d("MalService", "Staging our attack...");
        Log.d("MalService", "Attacking every 5 seconds...");
        Intent intent = new Intent(ctx,  MaliciousService.class);
        ctx.startService(intent);
    }
}
